<?php

$usernameErr = $fnameErr = "" ;

$username = $fname =  "" ;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(empty($_POST["username"])) {
        $usernameErr = "User Name Is Required";
        }
            else
            {
                $username = test_input($_POST["username"]);
            }

     if(empty($_POST["fname"])) {
        $fnameErr = "Name Is Required";
        }
            else
            {
                $fname = test_input($_POST["fname"]);
            }


   


    }


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
    }

?>