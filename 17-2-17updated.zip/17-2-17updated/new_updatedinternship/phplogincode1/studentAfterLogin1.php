
		

<?php 
    #include("Config.php");
	include("Session.php");
	//session_start();
	//$u_id = $_SESSION["u_id"];
 //if(isSet($_SESSION["u_id"])){
?>
<html>
<head>
<title>My Profile information</title>
   <!-- <link rel="stylesheet" type="text/css" href="menu.css"/>-->
	
</head>

<body>
<center>


<table>
<tr>
<td>
<div style="height: 510px; width: 470px;">
<!--  Second Column -->
<table border='3' cellspacing='5' cellpadding='5' bordercolor='3366FF' background='images/blueborder.jpg'>
	<tr>
		<td align="left" background=''><b>My Profile</b></td>
	</tr>
</table>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT employee_id ,fname,lname,area_of_interest,address1 FROM employee where username = '$user_check'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Employee Id: " . $row["employee_id"]. " Name: " . $row["fname"]. " " . $row["lname"]. "<br>";
		echo "Area of interest: " . $row["area_of_interest"]. " ";
		
		echo "Address1: " . $row["address1"]. " ";
	}
	
	
} else {
    echo "0 results";
}
$conn->close();
?>

</div>
</td>

</tr>
</table>

<?php
 #}
 #else
 
#
	#echo "<script language='javascript'>location.href='Login.php'</script>";
#
?>































