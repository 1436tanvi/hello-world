<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$usernameErr = "";
$username = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username"])) {
    $usernameErr = "UserName is required";
  } else {
    $username = test_input($_POST["username"]);
  }
  
 

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2></h2>
<p><span class="error">* required field.</span></p>
<form name="frmNewUserCreation" method="post" action="create_newuser.php" onSubmit="return validation(this)">
								<?php
									#include("Config.php");
									define('DB_SERVER', 'localhost');
									define('DB_USERNAME', 'root');
									define('DB_PASSWORD', '');
									define('DB_DATABASE', 'database1');
									$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
									
									#$path="upload/profiles/";
										
									if((isSet($_POST)) && (sizeof($_POST)>0)){	 
										$employee_type=$_POST["employee_type"];
										$username=$_POST["username"];
										$fname=$_POST["fname"];
										$lname=$_POST["lname"];
										$company_name=$_POST["company_name"]; 
										$password=$_POST["password"]; 
										$confirm_pwd=$_POST["confirm_pwd"];
										$date_of_join=date('Y-m-d',strtotime($_POST["date_of_join"]));
										$office_num=$_POST["office_num"];
										$mobile_num=$_POST["mobile_num"];
										#$password=hash('sha512',$_POST['stpassword']);
										$email_id=$_POST['email_id'];
										$address1=$_POST["address1"]; 
										$address2=$_POST["address2"]; 
										$country=$_POST["country"];
										$area_of_interest=$_POST["area_of_interest"]; 
									}
					
									if(isset($_POST['upload'])){
										if((isSet($_POST)) && (sizeof($_POST)>0)){	
											$query1 ="insert into admin (username,password) values('$username','$password');";
										mysqli_query($db,$query1);
										$u_id= mysqli_insert_id($db);
										
										
											$query2 ="insert into employee (employee_type,username,fname,lname,company_name,password,confirm_pwd,date_of_join,office_num,mobile_num,email_id,address1,address2,country,area_of_interest,u_id) values('$employee_type','$username','$fname','$lname','$company_name','$password','$confirm_pwd','$date_of_join','$office_num','$mobile_num','$email_id','$address1','$address2','$country','$area_of_interest','$u_id');";				
									
											$result = mysqli_query($db,$query2);									
										}		
									}
								?>
								<?php 
									if((isset($_POST)) && (sizeof($_POST)>0)){		
										echo"<table align'center' border='0' width='80%' cellpadding='3' cellspacing='2' class='stylized'>";
										echo"<tr align='left'>";
										echo"<td>Username</td>";
										echo"<td colspan='3'>$username</td>";	
										echo"</tr>";
				
										echo"<tr align='left'>";
										echo"<td nowrap>Employee Type</td>";
										echo"<td colspan='3'>$employee_type</td>";
										echo"</tr>";
				
										echo"<tr align='left'>";
										echo"<td>First Name</td>";
										echo"<td>$fname</td>";
										echo"<td nowrap>Last Name</td>";
										echo"<td>$lname</td>";
										echo"</tr>";				
					
										echo"<tr align='left'>";
										echo"<td>Company/Dept. Name</td>";
										echo"<td colspan='3'>$company_name</td>";
										echo"</tr>";
					
										echo"<tr nowrap align='left'>";
										echo"<td>Password</td>";
										echo"<td colspan='3'>$password</td>";
										echo"</tr>";
				
										echo"<tr nowrap align='left'>";
										echo"<td nowrap>Confirm Password</td>";
										echo"<td colspan='3'>$confirm_pwd</td>";
										echo"</tr>";
				
										echo"<tr nowrap align='left'>";
										echo"<td nowrap>Date of Joining</td>";
										echo"<td>$date_of_join</td>";	
										echo"</tr>";
										
										echo"<tr align='left'>";
										echo"<td>Office Number</td>";
										echo"<td>$office_num</td>";
										echo"<td nowrap>Mobile Number</td>";
										echo"<td>$mobile_num</td>";
										echo"</tr>";
					
										echo"<tr align='left'>";
										echo"<td>Email ID</td>";
										echo"<td colspan='3'>$email_id</td>";
										echo"</tr>";
					
										echo"<tr align='left'>";
										echo"<td>Address1</td>";
										echo"<td>$address1</td>";
										echo"<td>Address2</td>";
										echo"<td>$address2</td>";
										echo"</tr>";
											
										echo"<tr align='left'>";
										echo"<td>Country</td>";
										echo"<td colspan='3'>$country</td>";
										echo"</tr>";
											
										echo"<tr align='left'>";
										echo"<td>Area of Interest</td>";
										echo"<td colspan='3'>$area_of_interest</td>";
										echo"</tr>";
										echo"<table>";
									}
									else
									{
								?>
								<tr align="left">
									<td>Username</td>
									<td colspan="3"><input type="text" class="textbox" id="username" name="username" onFocus="disable_checkfield"
									onBlur="validate_empid();"></br>
									
									 <span class = "error">* <?php echo $usernameErr;?></span>
									
									
									</td>	
								</tr>
								
								<tr align="left">
									<td nowrap>Employee Type</td>
									<td colspan="3">
										<input type="text" class="textbox" id="employee_type" name="employee_type" value="Developer" readonly="true"></br>
									</td>
								</tr>
								<tr align="left">
									<td>First Name</td>
									<td>
										<input type="text" class="textbox" name="fname" id="fname"></br>
										<font color=red>*</font>
									</td>
									<td nowrap>Last Name</td>
									<td>
										<input type="text" class="textbox" name="lname" id="lname"></br>
										<font color=red>*</font>
									</td>
								</tr>
										
								<tr align="left">
									<td>Company/Dept. Name</td>
									<td colspan="3">
										<input type="text" class="textbox" name="company_name" id="company_name"></br>
										<font color=red>*</font>
									</td>
								</tr>
		
								<tr nowrap align="left">
									<td>Password</td>
									<td colspan="3">
										<input type="password" class="textbox" name="password" id="password"></br>
									
										
									</td>
								</tr>
										
								<tr nowrap align="left">	
									<td nowrap>Confirm Password</td>
										<td colspan="3">
											<input type="password" class="textbox" name="confirm_pwd" id="confirm_pwd"></br>
											<font color=red>*</font>
										</td>
								</tr>
								
								<tr nowrap align="left">
									<td nowrap>Date of Joining</td>
									<td> 	
										<input type="text" name="date_of_join" value="" id="date_of_join"></br>
										<font color=red>*</font>
										<a href="#" onClick="cal1.select(document.forms['frmNewUserCreation'].date_of_join,'anchor1','yyyy-MM-dd'); return false;" TITLE="Select Date" NAME="anchor1" ID="anchor1"><img src="img/calendar.jpg" border="0"/></a>
									</td>
								</tr>
					
								<tr align="left">
									<td>Office Number</td>
									<td>
										<input type="text" class="textbox" name="office_num" id="office_num"></br>
									</td>
									<td nowrap>
										Mobile Number
									</td>
									<td>
										<input type="text" class="textbox" name="mobile_num" id="mobile_num"></br>
									</td>
								</tr>		
								
								<tr align="left">
									<td>Email ID</td>
									<td colspan="3"><input type="text" class="textbox" name="email_id" id="email_id"></br>
									<font color=red>*</font></td>
								</tr>
					
								<tr align="left">
									<td>Address1</td>
									<td><textarea name="address1" id="address1"></textarea></td></br>
									<td>Address2</td>
									<td><textarea name="address2" id="address2"></textarea></td></br>
								</tr>
										
								<tr align="left">
									<td>Country</td>
									<td colspan="3">
										<select name="country" id="country">
											<option value="">Select</option>
											<option value="113">India</option>
											<option value="278">United States</option>
											<option value="1">Afghanistan</option>
											<option value="2">Alabama</option>
											<option value="3">Alaska</option>
											<option value="4">Albania</option>
											<option value="5">Alberta</option>
											<option value="6">Algeria</option>
											<option value="7">Amercan Samoa</option>
											<option value="8">Andorra</option>
											<option value="9">Angola</option>
											<option value="10">Anguilla</option>
											<option value="11">Antarctica</option>
											<option value="12">Antigua/Barbuda</option>
											<option value="13">Argentina</option>
											<option value="14">Arizona</option>
											<option value="15">Arkansas</option>
											<option value="16">Armenia</option>
											<option value="17">Aruba</option>
											<option value="18">Australia</option>
											<option value="19">Austria</option>
											<option value="20">Azerbaijan</option>
											<option value="21">Bahamas</option>
											<option value="22">Bahrain</option>
											<option value="23">Bangladesh</option>
											<option value="24">Barbados</option>
											<option value="25">Belarus</option>
											<option value="26">Belgium</option>
											<option value="27">Belize</option>
											<option value="28">Benin</option>
											<option value="29">Bermuda</option>
											<option value="30">Bhutan</option>
											<option value="31">Bolivia</option>
											<option value="32">Bosnia</option>
											<option value="33">Botswana</option>
											<option value="34">Bouvet Island</option>
											<option value="35">Brazil</option>
											<option value="36">British Columbia</option>
											<option value="37">British Indian OceanTerritory</option>
											<option value="38">BRUNEI DARUSSALAM</option>
											<option value="39">Bulgaria</option>
											<option value="40">Burkina Faso</option>
											<option value="41">Burundi</option>
											<option value="42">California</option>
											<option value="43">Cambodia</option>
											<option value="44">Cameroon</option>
											<option value="45">Canada</option>
											<option value="46">Cape Verde</option>
											<option value="47">Cayman Islands</option>
											<option value="48">Central African Republic</option>
											<option value="49">Chad</option>
											<option value="50">Chile</option>
											<option value="51">China</option>
											<option value="52">Christmas Island</option>
											<option value="53">Cocos (Keeling) Islands</option>
											<option value="54">Colombia</option>
											<option value="55">Colorado</option>
											<option value="56">Comoros</option>
											<option value="57">Congo</option>
											<option value="58">Congo, The Democratic Republic Of The</option>
											<option value="59">Connecticut</option>
											<option value="60">Cook Islands</option>
											<option value="61">Costa Rica</option>
											<option value="62">Cote d'Ivoire</option>
											<option value="63">Croatia</option>
											<option value="64">Cuba</option>
											<option value="65">Cyprus</option>
											<option value="66">Czech Republic</option>
											<option value="67">Delaware</option>
											<option value="68">Denmark</option>
											<option value="69">District Of Columbia</option>
											<option value="70">Djibouti</option>
											<option value="71">Dominica</option>
											<option value="72">Dominican Republic</option>
											<option value="73">East Timor</option>
											<option value="74">Ecuador</option>
											<option value="75">Egypt</option>
											<option value="76">El Salvador</option>
											<option value="77">Equatorial Guinea</option>
											<option value="78">Eritrea</option>
											<option value="79">Estonia</option>
											<option value="80">Ethiopia</option>
											<option value="81">Faeroe Islands</option>
											<option value="82">Falkland Islands</option>
											<option value="83">Fiji</option>
											<option value="84">Finland</option>
											<option value="85">Florida</option>
											<option value="86">France</option>
											<option value="87">French Guiana</option>
											<option value="88">French Polynesia</option>
											<option value="89">French Southern Territories</option>
											<option value="90">Gabon</option>
											<option value="91">Gambia</option>
											<option value="92">Georgia</option>
											<option value="93">Germany</option>
											<option value="94">Ghana</option>
											<option value="95">Gibraltar</option>
											<option value="96">Greece</option>
											<option value="97">Greenland</option>
											<option value="98">Grenada</option>
											<option value="99">Guadeloupe</option>
											<option value="100">Guam</option>
											<option value="101">Guatemala</option>
											<option value="102">Guinea</option>
											<option value="103">Guinea-Bissau</option>
											<option value="104">Guyana</option>
											<option value="105">Haiti</option>
											<option value="106">Hawaii</option>
											<option value="107">Heard And Mcdonald Islands</option>
											<option value="108">Honduras</option>
											<option value="109">Hungary</option>
											<option value="110">Iceland</option>
											<option value="111">Idaho</option>
											<option value="112">Illinois</option>
											<option value="113">India</option>
											<option value="114">Indiana</option>
											<option value="115">Indonesia</option>
											<option value="116">Iowa</option>
											<option value="117">Iran</option>
											<option value="118">Iraq</option>
											<option value="119">Ireland</option>
											<option value="120">Israel</option>
											<option value="121">Italy</option>
											<option value="122">Jamaica</option>
											<option value="123">Japan</option>
											<option value="124">Jordan</option>
											<option value="125">Kansas</option>
											<option value="126">Kazakhstan</option>
											<option value="127">Kentucky</option>
											<option value="128">Kenya</option>
											<option value="129">Kiribati</option>
											<option value="130">Korea Democratic people's republic of</option>
											<option value="131">Korea, Republic of</option>
											<option value="132">Kuwait</option>
											<option value="133">Kyrgyzstan</option>
											<option value="134">Lao, people's democratic republic</option>
											<option value="135">Latvia</option>
											<option value="136">Lebanon</option>
											<option value="137">Lesotho</option>
											<option value="138">Liberia</option>
											<option value="139">Libyan arab jamahiriya</option>
											<option value="140">Liechtenstein</option>
											<option value="141">Lithuania</option>
											<option value="142">Louisiana</option>
											<option value="143">Luxembourg</option>
											<option value="144">Macau</option>
											<option value="145">Macedonia, the former yugoslav republic of</option>
											<option value="146">Madagascar</option>
											<option value="147">Maine</option>
											<option value="148">Malawi</option>
											<option value="149">Malaysia</option>
											<option value="150">Maldives</option>
											<option value="151">Mali</option>
											<option value="152">Malta</option>
											<option value="153">Manitoba</option>
											<option value="154">Marshall Islands</option>
											<option value="155">Martinique</option>
											<option value="156">Maryland</option>
											<option value="157">Massachusetts</option>
											<option value="158">Mauritania</option>
											<option value="159">Mauritius</option>
											<option value="160">Mayotte</option>
											<option value="161">Mexico</option>
											<option value="162">Michigan</option>
											<option value="163">Micronesia, federated states of</option>
											<option value="164">Minnesota</option>
											<option value="165">Mississippi</option>
											<option value="166">Missouri</option>
											<option value="167">Moldova, republic of</option>
											<option value="168">Monaco</option>
											<option value="169">Mongolia</option>
											<option value="170">Montana</option>
											<option value="171">Montserrat</option>
											<option value="172">Morocco</option>
											<option value="173">Mozambique</option>
											<option value="174">Myanmar (Burma)</option>
											<option value="175">Namibia</option>
											<option value="176">Nauru</option>
											<option value="177">Nebraska</option>
											<option value="178">Nepal</option>
											<option value="179">Netherlands</option>
											<option value="180">Netherlands Antilles</option>
											<option value="181">Nevada</option>
											<option value="182">New Brunswick</option>
											<option value="183">New Caledonia</option>
											<option value="184">New England</option>
											<option value="185">New Hampshire</option>
											<option value="186">New Jersey</option>
											<option value="187">New Mexico</option>
											<option value="188">New York</option>
											<option value="189">New Zealand</option>
											<option value="190">Newfoundland</option>
											<option value="191">Nicaragua</option>
											<option value="192">Niger</option>
											<option value="193">Nigeria</option>
											<option value="194">Niue</option>
											<option value="195">Norfolk Island</option>
											<option value="196">North Carolina</option>
											<option value="197">North Dakota</option>
											<option value="198">Northern Mariana Islands</option>
											<option value="199">Northwest Territories</option>
											<option value="200">Norway</option>
											<option value="201">Nova Scotia</option>
											<option value="202">Ohio</option>
											<option value="203">Oklahoma</option>
											<option value="204">Oman</option>
											<option value="205">Ontario</option>
											<option value="206">Oregon</option>
											<option value="207">Pakistan</option>
											<option value="208">Palau</option>
											<option value="209">Palestinian territory, occupied</option>
											<option value="210">Panama</option>
											<option value="211">Papua New Guinea</option>
											<option value="212">Paraguay</option>
											<option value="213">Pennsylvania</option>
											<option value="214">Peru</option>
											<option value="215">Philippines</option>
											<option value="216">Pitcairn</option>
											<option value="217">Poland</option>
											<option value="218">Portugal</option>
											<option value="219">Prince Edward Island</option>
											<option value="220">Puerto Rico</option>
											<option value="221">Qatar</option>
											<option value="222">Quebec</option>
											<option value="223">Reunion</option>
											<option value="224">Rhode Island</option>
											<option value="225">Romania</option>
											<option value="226">Russian Federation</option>
											<option value="227">Rwanda</option>
											<option value="228">Saint Helena</option>
											<option value="229">Saint Kitts and Nevis</option>
											<option value="230">Saint Lucia</option>
											<option value="231">Saint pierre and miquelon</option>
											<option value="232">Saint Vincent and the Grenadines</option>
											<option value="233">Samoa</option>
											<option value="234">San Marino</option>
											<option value="235">Sao Tome And Principe</option>
											<option value="236">Saskatchewan</option>
											<option value="237">Saudi Arabia</option>
											<option value="238">Senegal</option>
											<option value="239">Seychelles</option>
											<option value="240">Sierra Leone</option>
											<option value="241">Singapore</option>
											<option value="242">Slovakia</option>
											<option value="243">Slovenia</option>
											<option value="244">Solomon Islands</option>
											<option value="245">Somalia</option>
											<option value="246">South Africa</option>
											<option value="247">South Carolina</option>
											<option value="248">South Dakota</option>
											<option value="249">South Georgia and the south sandwich Islands</option>
											<option value="250">Spain</option>
											<option value="251">Sri Lanka</option>
											<option value="252">Sudan</option>
											<option value="253">Suriname</option>
											<option value="254">Svalbard and Jan Mayen</option>
											<option value="255">Swaziland</option>
											<option value="256">Sweden</option>
											<option value="257">Switzerland</option>
											<option value="258">Syrian Arab Republic</option>
											<option value="259">Taiwan, Province of China</option>
											<option value="260">Tajikistan</option>
											<option value="261">Tanzania, United Republic Of</option>
											<option value="262">Tennessee</option>
											<option value="263">Texas</option>
											<option value="264">Thailand</option>
											<option value="265">Togo</option>
											<option value="266">Tokelau</option>
											<option value="267">Tonga</option>
											<option value="268">Trinidad And Tobago</option>
											<option value="269">Tunisia</option>
											<option value="270">Turkey</option>
											<option value="271">Turkmenistan</option>
											<option value="272">Turks And Caicos Islands</option>
											<option value="273">Tuvalu</option>											
											<option value="274">Uganda</option>
											<option value="275">Ukraine</option>
											<option value="276">United Arab Emirates</option>
											<option value="277">United Kingdom</option>
											<option value="278">United States</option>
											<option value="279">United States Minor Outlying Islands</option>
											<option value="280">Uruguay</option>
											<option value="281">Utah</option>
											<option value="282">Uzbekistan</option>
											<option value="283">Vanuatu</option>
											<option value="284">Vatican City State see HOLY SEE</option>
											<option value="285">Venezuela</option>
											<option value="286">Vermont</option>
											<option value="287">Vietnam</option>
											<option value="288">Virgin Islands (British)</option>
											<option value="289">Virgin Islands (U.S.)</option>
											<option value="290">Virginia</option>
											<option value="291">Wallis And Futuna Islands</option>
											<option value="292">Washington</option>
											<option value="293">West Virginia</option>
											<option value="294">Western Sahara</option>
											<option value="295">Wisconsin</option>
											<option value="296">Wyoming</option>
											<option value="297">Yemen</option>
											<option value="298">Yugoslavia</option>
											<option value="299">Yukon Territory</option>
											<option value="300">Zaire, Congo, the democratic republic of</option>
											<option value="301">Zambia</option>
											<option value="302">Zimbabwe</option>								
										</select>
										<font color=red>*</font>
									</td>
								</tr>
								<tr align="left">
									<td>Area of Interest</td>
									<td colspan="3">
										<textarea name="area_of_interest" id="area_of_interest" rows="3" cols="35"></textarea></br>
									</td>
								</tr>
								<tr align="left">
									<td>&nbsp;</td>
									<td colspan="3">
										<br>
										<input class="butclas" type="submit"  value="upload" name="upload">&nbsp;&nbsp;&nbsp;
										<input class="butclas" type="reset" value="Clear">
									</td>
								</tr>
								</form>
								<?php
									} 
									mysqli_close($db);
								?>

</body>
</html>