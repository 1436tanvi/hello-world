<?php

include("Session.php");
 ?>
<html>
<body>
<?php
//include('Config.php');
if(isset($_GET['emp_id']))
{
$emp_id=$_GET['emp_id'];

$query1=mysqli_query("delete from employee where username = '$user_check';;");
if($query1)
{
header('location:list.php');
}




}
?>
</body>
</html>