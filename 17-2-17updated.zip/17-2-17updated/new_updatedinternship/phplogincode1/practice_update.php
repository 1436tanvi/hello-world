<?php
	//include("Config.php");
	
	include("Session.php");
	
	#if(isset($_GET)){
		#$employee_id=$_GET["employee_id"];
	#}
	
	//define('DB_SERVER', 'localhost');
  	// define('DB_USERNAME', 'root');
       // define('DB_PASSWORD', '');
      // define('DB_DATABASE', 'database1');
   
	$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
	
	
	
?>
<html>
<head>
	<title>Employee Update Profile</title>
</head>
<body>
	<b>EDIT MY APPLICATION</b>
<?php 
	$query="select employee_id, fname,lname,address1,address2,country,email_id,office_num,mobile_num,date_of_join,area_of_interest from employee where username = '$user_check';;";
	
	$result = mysqli_query($db,$query) or die ("Error in query: ".$query." ".mysqli_connect_error());
	
	// see if any rows were returned 
	if(mysqli_num_rows($result)>0){ 
		// if yes print them one after another 
		echo "<table border='0' cellspacing='0' cellpadding='0'><tr>";
		while($row = mysqli_fetch_array($result)){ 
			echo "<br>
				<form action='updatedetailsAfterUpdation.php' method='post' enctype='multipart/form-data'>
					<font size=+1>
						<tr>
							<td>Employeee Id:</td>
							<td><input type='text' name='txtEmployeeId' id='txtEmployeeId' value ='".$row['employee_id']."'></td>
						</tr>
						
						<tr>
							<td>First Name:</td>
							<td><input type='text' name='txtFnameValue' id='txtFnameValue' value ='".$row['fname']."'></td>
						</tr>
						
						<tr>
							<td>Last Name:</td>
							<td><input type='text' name='txtLnameValue' id='txtLnameValue' value ='".$row['lname']."'></td>
						</tr>
						
						<tr>
							<td><br><font size=+1>Temporary Address :</td>
							<td><textarea name='txtAdd1' id='txtAdd1' rows='3' cols='20'>".$row['address1']."</textarea></td>
						</tr>
	
						<tr>
							<td><br><font size=+1>Permanent Address :</td>
							<td><textarea name='txtAdd2' id='txtAdd2' rows='3' cols='20'> ".$row['address2']."</textarea></td>
						</tr>
			
						<tr>
							<td><br><font size=+1>Country :</td>
							<td><input type='text' name='txtCountry' id='txtCountry' value='".$row['country']."'>
						</tr>	
						  
						<tr>
							<td><br><font size=+1>Office Number :</td>
							<td><input type='text' name='txtOfficeNo' id='txtOfficeNo' value='".$row['office_num']."'>
						</tr>
						  
						<tr>
							<td><br><font size=+1>Mobile Number :</td>
							<td><input type='text' name='txtMobileNo' id='txtMobileNo' value='".$row['mobile_num']."'>
						</tr>
		  
						<tr>
							<td><br><font size=+1>Email ID :</td>
							<td><input type='text' name='txtEmailId' id='txtEmailId' value='".$row['email_id']."'>
						</tr>
		
						<tr>
							<td><br><font size=+1>Date Of Joining :</td>
							<td><input type='text' name='txtDoj' id='txtDoj' value='".$row['date_of_join']."'></td>
						</tr>
		
						<tr>
							<td><br><font size=+1>Area of Interest :</td>
							<td><input type='text' name='txtAreaOfInterest' id='txtAreaOfInterest' value='".$row['area_of_interest']."'></td>
						</tr>
		
						<input type='hidden' name='txtEmployeeId' value='".$row['employee_id']."'>";
						echo "<tr><td><br><br></td></tr>";
						
						echo "<tr><td><input type='submit' name='submit' value='Upload Changed Data'></td></tr>
				</form>
		</table>";
		}
	} 
	else 
	{ 
		// print status message 
		"<blink>Profile Not Found</blink>"; 
	} 

	// free result set memory 
	mysqli_free_result($result); 
	mysqli_close($db);
?>
</body>
</html>