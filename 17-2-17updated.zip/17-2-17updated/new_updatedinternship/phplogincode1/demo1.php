<?php
   include('session.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Daily Status entry</title>
<link type="text/css" rel="stylesheet" href="css/style.css"/>


</head>

<body>
<h1>Welcome <?php echo $login_session; ?></h1> 
      <h2><a href = "logout.php">Log Out</a></h2>
<table border="0" align="center" width="1800px" cellpadding="0" cellspacing="0">
	<!-- header start -->
	<tr> 
		<td> 
			<table border="0" width="100%" align="center">
				<tr>
					<td><table border="0" width="1400px" "center" cellpadding="0" cellspacing="0">
	<tr>
		<td class="logbg">
		<table border="0" width="100%"  >
		<tr>			
			
		</tr>
		<tr>
			<td colspan="2" >
			<table  width="100%">
				
				<tr><td class="tss">Employee Timesheet</tr>
									<tr><td align="right"><b>Welcome </b><a href="view_employeeprofile.php" title="Edit your details">user</a>&nbsp;<span>|</span>&nbsp;<a href="logout.php">Logout</a></td></tr>
								</table>
			</td>			
		</tr>
		</table>
		</td>		
	</tr>
	<tr>
		<td class="bg1"><!-- for thick line - through css--></td>
	</tr>
	<tr>
		<td class="wpn_menu">
		<ul>
				<li><a class=currpageitemsel href="date_selection.php">Time Status Entry</a></li>
				<li><a  href="weekly_status_entry.php">Weekly Status Entry</a></li>
				<li><a  href="employee_report.php">Report</a></li>
				<li><a  href="studentAfterLogin1.php">My Profile</a></li>
				<li><a  href="password.php">Change Password</a></li>
				<li><a  href="search.php">search an employee</a></li>
                                <li><a  href="create_newuser.php">insert</a></li>
                                <li><a  href="edit_employee.php">edit</a></li>
                                
						</ul>		
		</td>
	</tr>
</table></td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- header end -->
	<tr>
		<td >
		<table border="0" width="98%" align="center" class="wpn_content">
			<tr>
				<td>
				<form name="frmDateEntry" action="employee_projectstatus.php"  method="post" onSubmit="return validation(this);">
				<table border="0" width="40%" align="center" cellpadding="3" cellspacing="2">				
				<tr><td align="center" class="tshead1" colspan="2">Daily Status entry</td></tr>
				<tr><td align="center" colspan="2">&nbsp;</td></tr>
				<tr>
					<td>Date</td>
					<td>
 						<INPUT TYPE="text" NAME="date" value="">
      					<A HREF="#" onClick="cal1.select(document.forms['frmDateEntry'].date,'anchor1','yyyy-MM-dd'); return false;" NAME="anchor1" ID="anchor1"><img src="img/calendar.jpg" border="0" title="selectdate"/></A>
					</td>
				</tr>
				<tr><td>&nbsp;</td>
					
					<td><input type="submit" name="submit" class="butclas" value="Hours Spent"></td>
				</tr>				
				</table>
				</form>
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<!-- footer start -->
	<tr> 
		<td> 
			<table border="0" width="100%">
				<tr>
					<td><div class="footer"><!--footer start-->
  
</div><!--footer end-->


</td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- footer end -->
</table>
</body>
</html>