<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Change password</title>
<link type="text/css" rel="stylesheet" href="css/style.css"/>
<script type="text/javascript"  language="javascript">
function validation(myform)
{ 		
	if(myform.oldpassword.value == "")
	{
		alert("Please enter old password");
		myform.oldpassword.focus();
		return false;
	}
	if(myform.newpassword.value == "")
	{
		document.getElementById("Warning_name").style.display="block";
		return false;
	}
	if(myform.confirmnewpassword.value == "")
	{
		alert("Please enter confirm password");
		myform.confirmnewpassword.focus();
		return false;
	}
	if(myform.confirmnewpassword.value != myform.newpassword.value)
	{
		alert("Password didnt match");
		myform.newpassword.focus();
		return false;
	}
	
	alert("Password can not be changed"); 
	return false;
}	
</script>
</head>

<body>
<table border="0" align="center" width="1024px" cellpadding="0" cellspacing="0">
	<!-- header start -->
	<tr> 
		<td> 
			<table border="0" width="100%" align="center">
				<tr>
					<td><table border="0" width="1000px" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td class="logbg">
		<table border="0" width="100%"  >
		<tr>			
			
			<td >
			
				<ins class="adsbygoogle"
					 style="display:inline-block;width:728px;height:90px"
					 data-ad-client="ca-pub-7088803035940952"
					 data-ad-slot="1233304725"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
			<!--adsense ad-->
			</td>
		</tr>
		<tr>
			<td colspan="2" >
			<table  width="100%">
				<tr><td align="right"><b>Sunday,February 12, 2017</b></td></tr>
				<tr><td class="tshead">Employee Timesheet-change password </td></tr>
									<tr><td align="right"><b>Welcome </b><a href="view_employeeprofile.php" title="Edit your details">user</a>&nbsp;<span>|</span>&nbsp;<a href="logout.php">Logout</a></td></tr>
								</table>
			</td>			
		</tr>
		</table>
		</td>		
	</tr>
	<tr>
		<td class="bg1"><!-- for thick line - through css--></td>
	</tr>
	<tr>
		<td class="wpn_menu">
		<ul>
							<li><a  href="date_selection.php">Time Status Entry</a></li>
				<li><a  href="weekly_status_entry.php">Weekly Status Entry</a></li>
				<li><a  href="employee_report.php">Report</a></li>
				<li><a  href="view_employeeprofile.php">My Profile</a></li>
				<li><a class=currpageitemsel href="changepassword.php">Change Password</a></li>
				
						</ul>		
		</td>
	</tr>
</table></td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- header end -->
	<tr>
		<td >
		<table border="0" width="98%" align="center" class="wpn_content">
		<tr><Td>
		<div  id="Warning_name" style="display:none; color:#FF0000; font-size:19px; " align="center">Warning: Please  enter new password.</div>
		
				  <table width="80%" border="0" align="center"  cellpadding="3" cellspacing="3" class="stylized">
						 <tr><td colspan="2" style="color:#CC0066; font-size:large; text-align:center;" >Change Password</td></tr>
						 						<tr>
							<td>
							<form name="form1" method="post" action="changepassword.php" onSubmit="return validation(this)">
							<table border="0" width="40%" align="center" cellpadding="2" cellspacing="2">
								<tr>						 
									  <td >Old password</td>
									  <td  ><input type="text" name="oldpassword"></td>
								</tr>
								<tr>
									  <td >New Password</td>
									  <td ><input type="password" name="newpassword"></td>
								</tr>
								<tr>
									  <td >Confirm New Password</td>
									  <td ><input type="password" name="confirmnewpassword"></td>
								</tr>
								<tr>
									 <td>&nbsp;</td><td  ><input type="submit" name="Submit" class="butclas" value="Submit"></td>
								</tr>
							</table>
							</form>
							</td>
						</tr>
				  </table>
			
			</Td></tr>
		</table>
		</td>
	</tr>
	<!-- footer start -->
	<tr> 
		<td> 
			<table border="0" width="100%">
				<tr>
					<td><div class="footer"><!--footer start-->
   
</div><!--footer end-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/57dd041a927cd860c83a9916/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--></td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- footer end -->
</table>
</body>
</html>