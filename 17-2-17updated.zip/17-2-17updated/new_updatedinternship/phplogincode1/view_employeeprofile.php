<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>view profile</title>
<link type="text/css" rel="stylesheet" href="css/style.css"/>
</head>

<body>
<table border="0" align="center" width="1024px" cellpadding="0" cellspacing="0">
	<!-- header start -->
	<tr> 
		<td> 
			<table border="0" width="100%" align="center">
				<tr>
					<td><table border="0" width="1000px" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td class="logbg">
		<table border="0" width="100%"  >
		<tr>			
			
			<td >
			<!--adsense ad-->
				<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- timesheet banner -->
				<ins class="adsbygoogle"
					 style="display:inline-block;width:728px;height:90px"
					 data-ad-client="ca-pub-7088803035940952"
					 data-ad-slot="1233304725"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
			<!--adsense ad-->
			</td>
		</tr>
		<tr>
			<td colspan="2" >
			<table  width="100%">
				<tr><td align="right"><b>Monday,February 13, 2017</b></td></tr>
				<tr><td class="tshead">qpt Online Timesheet </td></tr>
									<tr><td align="right"><b>Welcome </b><a href="view_employeeprofile.php" title="Edit your details">user</a>&nbsp;<span>|</span>&nbsp;<a href="logout.php">Logout</a></td></tr>
								</table>
			</td>			
		</tr>
		</table>
		</td>		
	</tr>
	<tr>
		<td class="bg1"><!-- for thick line - through css--></td>
	</tr>
	<tr>
		<td class="wpn_menu">
		<ul>
							<li><a  href="date_selection.php">Time Status Entry</a></li>
				<li><a  href="weekly_status_entry.php">Weekly Status Entry</a></li>
				<li><a  href="employee_report.php">Report</a></li>
				<li><a class=currpageitemsel href="view_employeeprofile.php">My Profile</a></li>
				<li><a  href="changepassword.php">Change Password</a></li>
				
						</ul>		
		</td>
	</tr>
</table></td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- header end -->
	<tr>
		<td>
		<table border="0" width="98%" align="center" class="wpn_content">
			<tr>
				<td>
				<form name="frmEditEmployeeDetails" method="post"  action="employee_profile.php">
				<table border="0" width="85%" align="center" cellpadding="3" cellspacing="1" class="stylized">
					<tr><td align="center" class="prj_nam_cls" colspan="4">View Profile</td></tr>
										
					<input type="hidden" name="id" value="1259" >
					<input type="hidden" name="admin_id" value="3">
					<tr>
						<td class="labeltext">First Name </td>
						<td><input type="text" name="first_name" value="user" readonly="true"/></td>
						<td class="labeltext">Last Name</td>
						<td><input type="text" name="last_name" value="" readonly="true"/></td>
					</tr>
					
					<tr>
						<td class="labeltext">Date Of Join </td>
						
						<td><input type="text" name="date_of_join" value="2017-01-17" readonly="true"/>
	
						</td>
					
						<td class="labeltext">Email ID </td>
						<td><input type="text" name="email_id" value="user@qualitypointtech.net" readonly="true"/></td>
					</tr>
					<tr>
						<td class="labeltext">Mobile Number</td>
						<td><input type="text" name="mob_number" value="123123" readonly="true"/></td>
						<td class="labeltext">Office Number</td>
						<td><input type="text" name="office_number" value="" readonly="true"/></td>
					</tr>
					
					<tr>
						<td class="labeltext">Address1</td>
						<td><textarea name="address1" readonly="true"></textarea></td>
						<td class="labeltext">Address2</td>
						<td><textarea name="address2" readonly="true"></textarea></td>
					</tr>
					<Tr>
					<TD class="labeltext">Country </TD>
					<TD colspan="4"><select name="country" id="country" disabled="disabled">
									<option value="">Select</option>
									<option value="113">India</option>
									<option value="278">Uinted States</option>
																				<option value="1"  >Afghanistan</option>
																				<option value="2"  >Alabama</option>
																				<option value="3"  >Alaska</option>
																				<option value="4"  >Albania</option>
																				<option value="5"  >Alberta</option>
																				<option value="6"  >Algeria</option>
																				<option value="7"  >Amercan Samoa</option>
																				<option value="8"  >Andorra</option>
																				<option value="9"  >Angola</option>
																				<option value="10"  >Anguilla</option>
																				<option value="11"  >Antarctica</option>
																				<option value="12" selected >Antigua/Barbuda</option>
																				<option value="13"  >Argentina</option>
																				<option value="14"  >Arizona</option>
																				<option value="15"  >Arkansas</option>
																				<option value="16"  >Armenia</option>
																				<option value="17"  >Aruba</option>
																				<option value="18"  >Australia</option>
																				<option value="19"  >Austria</option>
																				<option value="20"  >Azerbaijan</option>
																				<option value="21"  >Bahamas</option>
																				<option value="22"  >Bahrain</option>
																				<option value="23"  >Bangladesh</option>
																				<option value="24"  >Barbados</option>
																				<option value="25"  >Belarus</option>
																				<option value="26"  >Belgium</option>
																				<option value="27"  >Belize</option>
																				<option value="28"  >Benin</option>
																				<option value="29"  >Bermuda</option>
																				<option value="30"  >Bhutan</option>
																				<option value="31"  >Bolivia</option>
																				<option value="32"  >Bosnia</option>
																				<option value="33"  >Botswana</option>
																				<option value="34"  >Bouvet Island</option>
																				<option value="35"  >Brazil</option>
																				<option value="36"  >British Columbia</option>
																				<option value="37"  >British Indian OceanTerritory</option>
																				<option value="38"  >BRUNEI DARUSSALAM</option>
																				<option value="39"  >Bulgaria</option>
																				<option value="40"  >Burkina Faso</option>
																				<option value="41"  >Burundi</option>
																				<option value="42"  >California</option>
																				<option value="43"  >Cambodia</option>
																				<option value="44"  >Cameroon</option>
																				<option value="45"  >Canada</option>
																				<option value="46"  >Cape Verde</option>
																				<option value="47"  >Cayman Islands</option>
																				<option value="48"  >Central African Republic</option>
																				<option value="49"  >Chad</option>
																				<option value="50"  >Chile</option>
																				<option value="51"  >China</option>
																				<option value="52"  >Christmas Island</option>
																				<option value="53"  >Cocos (Keeling) Islands</option>
																				<option value="54"  >Colombia</option>
																				<option value="55"  >Colorado</option>
																				<option value="56"  >Comoros</option>
																				<option value="57"  >Congo</option>
																				<option value="58"  >Congo, The Democratic Republic Of The</option>
																				<option value="59"  >Connecticut</option>
																				<option value="60"  >Cook Islands</option>
																				<option value="61"  >Costa Rica</option>
																				<option value="62"  >Cote d'Ivoire</option>
																				<option value="63"  >Croatia</option>
																				<option value="64"  >Cuba</option>
																				<option value="65"  >Cyprus</option>
																				<option value="66"  >Czech Republic</option>
																				<option value="67"  >Delaware</option>
																				<option value="68"  >Denmark</option>
																				<option value="69"  >District Of Columbia</option>
																				<option value="70"  >Djibouti</option>
																				<option value="71"  >Dominica</option>
																				<option value="72"  >Dominican Republic</option>
																				<option value="73"  >East Timor</option>
																				<option value="74"  >Ecuador</option>
																				<option value="75"  >Egypt</option>
																				<option value="76"  >El Salvador</option>
																				<option value="77"  >Equatorial Guinea</option>
																				<option value="78"  >Eritrea</option>
																				<option value="79"  >Estonia</option>
																				<option value="80"  >Ethiopia</option>
																				<option value="81"  >Faeroe Islands</option>
																				<option value="82"  >Falkland Islands</option>
																				<option value="83"  >Fiji</option>
																				<option value="84"  >Finland</option>
																				<option value="85"  >Florida</option>
																				<option value="86"  >France</option>
																				<option value="87"  >French Guiana</option>
																				<option value="88"  >French Polynesia</option>
																				<option value="89"  >French Southern Territories</option>
																				<option value="90"  >Gabon</option>
																				<option value="91"  >Gambia</option>
																				<option value="92"  >Georgia</option>
																				<option value="93"  >Germany</option>
																				<option value="94"  >Ghana</option>
																				<option value="95"  >Gibraltar</option>
																				<option value="96"  >Greece</option>
																				<option value="97"  >Greenland</option>
																				<option value="98"  >Grenada</option>
																				<option value="99"  >Guadeloupe</option>
																				<option value="100"  >Guam</option>
																				<option value="101"  >Guatemala</option>
																				<option value="102"  >Guinea</option>
																				<option value="103"  >Guinea-Bissau</option>
																				<option value="104"  >Guyana</option>
																				<option value="105"  >Haiti</option>
																				<option value="106"  >Hawaii</option>
																				<option value="107"  >Heard And Mcdonald Islands</option>
																				<option value="108"  >Honduras</option>
																				<option value="109"  >Hungary</option>
																				<option value="110"  >Iceland</option>
																				<option value="111"  >Idaho</option>
																				<option value="112"  >Illinois</option>
																				<option value="113"  >India</option>
																				<option value="114"  >Indiana</option>
																				<option value="115"  >Indonesia</option>
																				<option value="116"  >Iowa</option>
																				<option value="117"  >Iran</option>
																				<option value="118"  >Iraq</option>
																				<option value="119"  >Ireland</option>
																				<option value="120"  >Israel</option>
																				<option value="121"  >Italy</option>
																				<option value="122"  >Jamaica</option>
																				<option value="123"  >Japan</option>
																				<option value="124"  >Jordan</option>
																				<option value="125"  >Kansas</option>
																				<option value="126"  >Kazakhstan</option>
																				<option value="127"  >Kentucky</option>
																				<option value="128"  >Kenya</option>
																				<option value="129"  >Kiribati</option>
																				<option value="130"  >Korea Democratic people's republic of</option>
																				<option value="131"  >Korea, Republic of</option>
																				<option value="132"  >Kuwait</option>
																				<option value="133"  >Kyrgyzstan</option>
																				<option value="134"  >Lao, people's democratic republic</option>
																				<option value="135"  >Latvia</option>
																				<option value="136"  >Lebanon</option>
																				<option value="137"  >Lesotho</option>
																				<option value="138"  >Liberia</option>
																				<option value="139"  >Libyan arab jamahiriya</option>
																				<option value="140"  >Liechtenstein</option>
																				<option value="141"  >Lithuania</option>
																				<option value="142"  >Louisiana</option>
																				<option value="143"  >Luxembourg</option>
																				<option value="144"  >Macau</option>
																				<option value="145"  >Macedonia, the former yugoslav republic of</option>
																				<option value="146"  >Madagascar</option>
																				<option value="147"  >Maine</option>
																				<option value="148"  >Malawi</option>
																				<option value="149"  >Malaysia</option>
																				<option value="150"  >Maldives</option>
																				<option value="151"  >Mali</option>
																				<option value="152"  >Malta</option>
																				<option value="153"  >Manitoba</option>
																				<option value="154"  >Marshall Islands</option>
																				<option value="155"  >Martinique</option>
																				<option value="156"  >Maryland</option>
																				<option value="157"  >Massachusetts</option>
																				<option value="158"  >Mauritania</option>
																				<option value="159"  >Mauritius</option>
																				<option value="160"  >Mayotte</option>
																				<option value="161"  >Mexico</option>
																				<option value="162"  >Michigan</option>
																				<option value="163"  >Micronesia, federated states of</option>
																				<option value="164"  >Minnesota</option>
																				<option value="165"  >Mississippi</option>
																				<option value="166"  >Missouri</option>
																				<option value="167"  >Moldova, republic of</option>
																				<option value="168"  >Monaco</option>
																				<option value="169"  >Mongolia</option>
																				<option value="170"  >Montana</option>
																				<option value="171"  >Montserrat</option>
																				<option value="172"  >Morocco</option>
																				<option value="173"  >Mozambique</option>
																				<option value="174"  >Myanmar (Burma)</option>
																				<option value="175"  >Namibia</option>
																				<option value="176"  >Nauru</option>
																				<option value="177"  >Nebraska</option>
																				<option value="178"  >Nepal</option>
																				<option value="179"  >Netherlands</option>
																				<option value="180"  >Netherlands Antilles</option>
																				<option value="181"  >Nevada</option>
																				<option value="182"  >New Brunswick</option>
																				<option value="183"  >New Caledonia</option>
																				<option value="184"  >New England</option>
																				<option value="185"  >New Hampshire</option>
																				<option value="186"  >New Jersey</option>
																				<option value="187"  >New Mexico</option>
																				<option value="188"  >New York</option>
																				<option value="189"  >New Zealand</option>
																				<option value="190"  >Newfoundland</option>
																				<option value="191"  >Nicaragua</option>
																				<option value="192"  >Niger</option>
																				<option value="193"  >Nigeria</option>
																				<option value="194"  >Niue</option>
																				<option value="195"  >Norfolk Island</option>
																				<option value="196"  >North Carolina</option>
																				<option value="197"  >North Dakota</option>
																				<option value="198"  >Northern Mariana Islands</option>
																				<option value="199"  >Northwest Territories</option>
																				<option value="200"  >Norway</option>
																				<option value="201"  >Nova Scotia</option>
																				<option value="202"  >Ohio</option>
																				<option value="203"  >Oklahoma</option>
																				<option value="204"  >Oman</option>
																				<option value="205"  >Ontario</option>
																				<option value="206"  >Oregon</option>
																				<option value="207"  >Pakistan</option>
																				<option value="208"  >Palau</option>
																				<option value="209"  >Palestinian territory, occupied</option>
																				<option value="210"  >Panama</option>
																				<option value="211"  >Papua New Guinea</option>
																				<option value="212"  >Paraguay</option>
																				<option value="213"  >Pennsylvania</option>
																				<option value="214"  >Peru</option>
																				<option value="215"  >Philippines</option>
																				<option value="216"  >Pitcairn</option>
																				<option value="217"  >Poland</option>
																				<option value="218"  >Portugal</option>
																				<option value="219"  >Prince Edward Island</option>
																				<option value="220"  >Puerto Rico</option>
																				<option value="221"  >Qatar</option>
																				<option value="222"  >Quebec</option>
																				<option value="223"  >Reunion</option>
																				<option value="224"  >Rhode Island</option>
																				<option value="225"  >Romania</option>
																				<option value="226"  >Russian Federation</option>
																				<option value="227"  >Rwanda</option>
																				<option value="228"  >Saint Helena</option>
																				<option value="229"  >Saint Kitts and Nevis</option>
																				<option value="230"  >Saint Lucia</option>
																				<option value="231"  >Saint pierre and miquelon</option>
																				<option value="232"  >Saint Vincent and the Grenadines</option>
																				<option value="233"  >Samoa</option>
																				<option value="234"  >San Marino</option>
																				<option value="235"  >Sao Tome And Principe</option>
																				<option value="236"  >Saskatchewan</option>
																				<option value="237"  >Saudi Arabia</option>
																				<option value="238"  >Senegal</option>
																				<option value="239"  >Seychelles</option>
																				<option value="240"  >Sierra Leone</option>
																				<option value="241"  >Singapore</option>
																				<option value="242"  >Slovakia</option>
																				<option value="243"  >Slovenia</option>
																				<option value="244"  >Solomon Islands</option>
																				<option value="245"  >Somalia</option>
																				<option value="246"  >South Africa</option>
																				<option value="247"  >South Carolina</option>
																				<option value="248"  >South Dakota</option>
																				<option value="249"  >South Georgia and the south sandwich Islands</option>
																				<option value="250"  >Spain</option>
																				<option value="251"  >Sri Lanka</option>
																				<option value="252"  >Sudan</option>
																				<option value="253"  >Suriname</option>
																				<option value="254"  >Svalbard and Jan Mayen</option>
																				<option value="255"  >Swaziland</option>
																				<option value="256"  >Sweden</option>
																				<option value="257"  >Switzerland</option>
																				<option value="258"  >Syrian Arab Republic</option>
																				<option value="259"  >Taiwan, Province of China</option>
																				<option value="260"  >Tajikistan</option>
																				<option value="261"  >Tanzania, United Republic Of</option>
																				<option value="262"  >Tennessee</option>
																				<option value="263"  >Texas</option>
																				<option value="264"  >Thailand</option>
																				<option value="265"  >Togo</option>
																				<option value="266"  >Tokelau</option>
																				<option value="267"  >Tonga</option>
																				<option value="268"  >Trinidad And Tobago</option>
																				<option value="269"  >Tunisia</option>
																				<option value="270"  >Turkey</option>
																				<option value="271"  >Turkmenistan</option>
																				<option value="272"  >Turks And Caicos Islands</option>
																				<option value="273"  >Tuvalu</option>
																				<option value="274"  >Uganda</option>
																				<option value="275"  >Ukraine</option>
																				<option value="276"  >United Arab Emirates</option>
																				<option value="277"  >United Kingdom</option>
																				<option value="278"  >United States</option>
																				<option value="279"  >United States Minor Outlying Islands</option>
																				<option value="280"  >Uruguay</option>
																				<option value="281"  >Utah</option>
																				<option value="282"  >Uzbekistan</option>
																				<option value="283"  >Vanuatu</option>
																				<option value="284"  >Vatican City State see HOLY SEE</option>
																				<option value="285"  >Venezuela</option>
																				<option value="286"  >Vermont</option>
																				<option value="287"  >Vietnam</option>
																				<option value="288"  >Virgin Islands (British)</option>
																				<option value="289"  >Virgin Islands (U.S.)</option>
																				<option value="290"  >Virginia</option>
																				<option value="291"  >Wallis And Futuna Islands</option>
																				<option value="292"  >Washington</option>
																				<option value="293"  >West Virginia</option>
																				<option value="294"  >Western Sahara</option>
																				<option value="295"  >Wisconsin</option>
																				<option value="296"  >Wyoming</option>
																				<option value="297"  >Yemen</option>
																				<option value="298"  >Yugoslavia</option>
																				<option value="299"  >Yukon Territory</option>
																				<option value="300"  >Zaire, Congo, the democratic republic of</option>
																				<option value="301"  >Zambia</option>
																				<option value="302"  >Zimbabwe</option>
																		 </select>
					</td></Tr>
					<tr>
						<td class="labeltext">Area Of Interest</td>
						<td colspan="3"><textarea name="area_of_interest" readonly="true">american</textarea></td>
					
						
						
					</tr>
					<tr><td colspan="4" align="center"><input type="submit" name="edit" class="butclas" value="Edit  Details" /></td></tr>					
				</table>
				</form>
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<!-- footer start -->
	<tr> 
		<td> 
			<table border="0" width="100%">
				<tr>
					<td><div class="footer"><!--footer start-->
   
</div><!--footer end-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/57dd041a927cd860c83a9916/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--></td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- footer end -->
</table>
</body>
</html>