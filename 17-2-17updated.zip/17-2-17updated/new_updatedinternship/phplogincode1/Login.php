<?php
   include("Config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $username = mysqli_real_escape_string($db,$_POST['username']);
      $password = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT u_id FROM admin WHERE username = '$username' and password = '$password'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         
         $_SESSION['login_user'] = $username;
         
         header("location: demo1.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
		 
		 .error {color: #FF0000;}
		 
		 
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
   
   
   <?php
         // define variables and set to empty values
         $usernameErr = $passErr = "";
         $username = $password = "";
         
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["username"])) {
               $usernameErr = "UserName is required";
            }else {
               $username = test_input($_POST["username"]);
            }
            
            if (empty($_POST["password"])) {
               $passErr = "Password is required";
            }else {
               $password = test_input($_POST["password"]);
               
               
               }
            }
            
         
         function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
      ?>
     
   
   
   
   
   
   
   
   
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               <p><span class = "error">* REQUIRED FIELD.</span></p>
               <form action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name="username" pattern="[a-zA-Z\s]+"/ title="no numeric input allowed" required><br /><br />
				   <span class = "error">* <?php echo $usernameErr;?></span><br/>
				  
                  <label>Password  :</label><input type = "password" name="password" pattern=".{6,}" title="Six or more characters" required ><br/><br />
				   <span class = "error">* <?php echo $passErr;?></span><br/>
				  
                  <input type = "submit" value = " Submit "/><br />
               </form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"></div>
					
            </div>
		<a  href="create_newuser.php">insert</a>		
         </div>
			
      </div>

   </body>
</html>