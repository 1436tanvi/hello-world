
<?php 
   // #include("Config.php");
	include("Session.php");
	//session_start();
	//$u_id = $_SESSION["u_id"];
 //if(isSet($_SESSION["u_id"])){
?>





<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html">
	<title>Employee Timesheet </title>
	<link type="text/css" rel="stylesheet" href="css/style.css"/>
	<script type="text/javascript" src="main.js"></script>
	
	<script language="javascript">
		function delete_confirm(empid){
			var delte_status=confirm('Are you sure want to delete this Employee?');
			if(delte_status){
				window.location.href='delete_records.php?id='+empid;
			}
			return delte_status;
		}
	</script>
</head>
<body>
<table border="0" align="center" width="1024px" cellpadding="0" cellspacing="0">
	<!-- header start -->
	<tr> 
		<td> 
			<table border="0" width="100%" align="center">
				<tr>
					<td>
						<table border="0" width="1000px" align="center" cellpadding="0" cellspacing="0">
							<tr>
								<td class="logbg">
									<table border="0" width="100%"  >
										<tr>			
											<td>
												<a href=""><img src="" border="0"/></a>		
											</td>
											<td>
											</td>
										</tr>
										<tr>
											<td colspan="2">
												<table  width="100%">
													<tr>
														<td align="right">
															<b>Monday,February 13, 2017</b>
														</td>
													</tr>
													<tr>
														<td class="tshead">Employee Timesheet</td>
													</tr>
													<tr>
														<td align="right"><b>Welcome</b>
															<a href="edit_employeedetails.php?id=3" title="Edit your details">admin</a>&nbsp;<span>|</span>&nbsp;
															<a href="logout.php">Logout</a>
														</td>
													</tr>
													<tr><td>&nbsp;</td></tr>
													<tr>
														<td class="tshead1">
															<b>Number of Employees :</b>10 | 
															<b>Total Projects :</b>3 | 
																			
														</td>
													</tr>
												</table>
											</td>			
										</tr>
									</table>
								</td>		
							</tr>
							<tr>
								<td class="bg1"><!-- for thick line - through css--></td>
							</tr>
							<tr>
								<td class="wpn_menu">
									<ul>
										<li><a class=currpageitemsel href="edit_employee.php">Employee Details</a></li>
										<li><a  href="edit_project.php">Project Details</a></li>
										<li><a  href="weekly_status_entry.php">Weekly Status</a></li>
										<li><a  href="admin_date_selection.php">Daily Status</a></li>
										<li><a  href="defaulter_list.php">Defaulter List</a></li>
										<li><a  href="admin_report.php">Report</a></li>
										<li><a  href="changepassword.php">Change Password</a></li>
									</ul>		
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<!-- header end -->
	
		
	
	
	
	
	
	
	
	<tr>
		<td>
			<table border="0" width="98%" align="center" class="wpn_content">
				<tr>
					<td align="right"><a href="create_newuser.php">Create New User</a></td>
				</tr>
				<tr>
					<td>
						<?php
							$dbhost = 'localhost';
							$dbuser = 'root';
							$dbpass = '';
							$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
							if(! $conn ){
								die('Could not connect: ' . mysqli_connect_error());
							}

							$sql = "select username,fname,lname,email_id from employee where username = '$user_check';";
							mysqli_select_db($conn,"database1");
							$retval = mysqli_query($conn,$sql);
	
							if(! $retval ){
								die('Could not get data: ' . mysqli_connect_error());
							}
						?>
				
						<table border="1" align="center" width="60%" cellpadding="2" cellspacing="2">
							<tr>
								<td class="headerStyle" height="40px">Username</td>
								<td class="headerStyle" height="40px">Name</td>
								<td class="headerStyle" height="40px">Emailid</td>
								<td class="headerStyle" height="40px" width="20px">Edit</td>
								<td class="headerStyle" height="40px" width="20px">View</td>
								<td class="headerStyle" height="40px" width="20px">Delete</td>
								<!--<td class="headerStyle" height="40px" width="20px">UnLock TimeSheet</td> -->
							</tr>
						<?php
							while($row = mysqli_fetch_array($retval, MYSQL_ASSOC)){
								echo "<tr><td>{$row['username']}</td><td>{$row['fname']} {$row['lname']}</td><td>{$row['email_id']}</td>
								<td><a href='practice_update.php'><img src='img/edituser.jpg' border='0' title='Edit Employee' alt='edit icon' width='25' height='25'></a></td>     
					
								<td><a href=''><img src='img/view.JPG' border='0' width='20' height='20' title='view'/></a></td>
								
								<td><a href='delete.php' onClick=''><img src='img/delete.jpg' border='0' width='20' height='20' title='Delete Employee'></a></td></tr>";
								//<a href='delete.php?emp_id=".$row['emp_id']."'>
							}
							#echo "Fetched data successfully from the database \n";
							mysqli_close($conn);
						?>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
					


					
					
					
	
	
	
	<!-- footer start here---------------------- -->
	<tr> 
		<td> 
			<table border="0" width="100%">
				<tr>
					<td>
						<div class="footer"><!--footer start-->
							<p align="center" style="vertical-align:middle; ">
								<font>   </font><span><a href="" title="" target="_blank"></a></span>
							</p>
						</div><!--footer end-->
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<!-- footer end -->
</table>
</body>
</html>