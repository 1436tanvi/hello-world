<?php
	//include("Config.php"); 
		include("Session.php");
	/*
	if(isset($_POST)&&(sizeof($_POST)>0)){
		$employee_id=$_POST['employee_id'];
	}
	*/
	   //$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
	
	$txtFnameValue=$_POST['txtFnameValue'];
	$txtLnameValue=$_POST['txtLnameValue'];
	$txtAdd1=$_POST['txtAdd1'];
	$txtAdd2=$_POST['txtAdd2'];
	$txtCountry=$_POST['txtCountry'];
	$txtOfficeNo=$_POST['txtOfficeNo'];
	$txtMobileNo=$_POST['txtMobileNo'];
	$txtEmailId=$_POST['txtEmailId'];
	$txtDoj=$_POST['txtDoj'];
	$txtAreaOfInterest=$_POST['txtAreaOfInterest'];
		
	$query_update="update employee set email_id='".$txtEmailId."',mobile_num='".$txtMobileNo."',office_num='".$txtOfficeNo."',fname='".$txtFnameValue."',lname='".$txtLnameValue."',address1='".$txtAdd1."',address2='".$txtAdd2."',country='".$txtCountry."',date_of_join='".$txtDoj."',area_of_interest='".$txtAreaOfInterest."' where username = '$user_check';;";
	
	$result1=mysqli_query($db,$query_update) or die ("Error in query: ".$query_update." ".mysqli_connect_error());;	
	
	echo "<script language='javascript'>window.alert('Updation done Successfully')</script>";
	#echo "<script language='javascript'>location.href='main2.php'</script>";
?>