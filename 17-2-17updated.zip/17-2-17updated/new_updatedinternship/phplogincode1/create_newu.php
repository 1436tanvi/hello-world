<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>New Employee Registration Form - Employee Timesheet </title>
		
		<link type="text/css" rel="stylesheet" href="css/style.css"/>
		<script type="text/javascript" src="main.js" charset="UTF-8"></script>
		<script language="javascript">
		
	
	</script>
	<script language="JavaScript" src="CalendarPopup.js"></script>
	<script language="JavaScript" id="js1">
		var cal1 = new CalendarPopup();
	</script>
	</head>
	
	<body>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		<table border="0" align="center" width="1024px" cellpadding="0" cellspacing="0">
			<!-- header start -->
			<tr> 
				<td> 
					<table border="0" width="100%" align="center">
						<tr>
							<td><table border="0" width="1000px" align="center" cellpadding="0" cellspacing="0">
						<tr>
							<td class="logbg">
								<table border="0" width="100%">
							
							<tr>			
								<td>
									<a href=""><img src="" border="0"/></a>		
								</td>
						
							</tr>
							
							<tr>
								<td colspan="2" >
									<table  width="100%">
										<tr><td align="right"><b></b></td></tr>
										<tr><td class="tshead">Employee Timesheet </td></tr>
										<tr><td align="right"><b>Welcome </b>
											<a href="edit_employeedetails.php?id=3" title="Edit your details">user</a>&nbsp;<span>|</span>&nbsp;<a href="logout.php">Logout</a></td>
										</tr>
										<tr><td>&nbsp;</td></tr>
										<tr>
											<td class="tshead1">
												<b>Number of Employees :</b> | 
												<b>Total Projects :</b> | 
											</td>
										</tr>
									</table>
								</td>			
							</tr>
						</table>
						</td>		
						</tr>
						<tr>
							<td class="bg1"><!-- for thick line - through css--></td>
						</tr>
						<tr>
							<td class="wpn_menu">
								<ul>
									<li><a href="edit_employee.php">Employee Details</a></li>
									<li><a href="edit_project.php">Project Details</a></li>
									<li><a href="weekly_status_entry.php">Weekly Status</a></li>
									<li><a href="admin_date_selection.php">Daily Status</a></li>
									<li><a href="defaulter_list.php">Defaulter List</a></li>
									<li><a href="admin_report.php">Report</a></li>
									<li><a href="changepassword.php">Change Password</a></li>
								</ul>		
							</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
			</td>
		</tr>
		<!-- header end -->
		<tr>
			<td>
				<table border="0" width="98%" align="center" class="wpn_content">
					<tr align="center">
						<td colspan="2" class="tshead1">New Employee Registration Form</td>
					</tr>		
					<tr>			
						<td align="left">
							Note:<font color=red>*</font>Fields are mandatory.
						</td>
						<td align="right">
							<a href="edit_employee.php" title="Edit Employee" tabindex="3" accesskey="o">Employee Details</a>
							<br>
						</td>
			 		</tr>
					<tr align="center">	
						<td colspan="2">
							<table border="0" width="98%" align="center" class="wpn_content">
								<tr align="center">
									<td colspan="2" class="tshead1">New Employee Registration Form</td>
								</tr>		
	
								<tr>			
									<td align="left">
										Note:<font color=red>*</font>Fields are mandatory.
									</td>
		
									<td align="right">				
										<a href="edit_employee.php" title=" Edit Employee" tabindex="3" accesskey="o">Employee Details</a><br>
									</td>
								</tr>
								
								
								
							
								
								
								
								
								
								
								
								
								
								
								
								
	
					<tr align="center">	
						<td colspan="2">
							<table align="center" border="0" width="80%" cellpadding="3" cellspacing="2" class="stylized">
							 <p><span class = "error">* required field.</span></p>
								<form name="frmNewUserCreation" method="post" onSubmit="return validation(this)" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
								<?php
									#include("Config.php");
									define('DB_SERVER', 'localhost');
									define('DB_USERNAME', 'root');
									define('DB_PASSWORD', '');
									define('DB_DATABASE', 'database1');
									$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
									
									#$path="upload/profiles/";
										
									if((isSet($_POST)) && (sizeof($_POST)>0)){	 
										//$employee_type=$_POST["employee_type"];
										$username=$_POST["username"];
										//$fname=$_POST["fname"];
										//$lname=$_POST["lname"];
										//$company_name=$_POST["company_name"]; 
										//$password=$_POST["password"]; 
										//$confirm_pwd=$_POST["confirm_pwd"];
										//$date_of_join=date('Y-m-d',strtotime($_POST["date_of_join"]));
										//$office_num=$_POST["office_num"];
										//$mobile_num=$_POST["mobile_num"];
										#$password=hash('sha512',$_POST['stpassword']);
										//$email_id=$_POST['email_id'];
										//$address1=$_POST["address1"]; 
										//$address2=$_POST["address2"]; 
										//$country=$_POST["country"];
										//$area_of_interest=$_POST["area_of_interest"]; 
									}
					
									if(isset($_POST['upload'])){
										if((isSet($_POST)) && (sizeof($_POST)>0)){	
											$query1 ="insert into admin (username) values('$username');";
										mysqli_query($db,$query1);
										$u_id= mysqli_insert_id($db);
										
										
											$query2 ="insert into employee (username) values('$username');";				
									
											$result = mysqli_query($db,$query2);									
										}		
									}
								?>
								<?php 
									if((isset($_POST)) && (sizeof($_POST)>0)){		
										echo"<table align'center' border='0' width='80%' cellpadding='3' cellspacing='2' class='stylized'>";
										echo"<tr align='left'>";
										echo"<td>Username</td>";
										echo"<td colspan='3'>$username</td>";	
										echo"</tr>";
				
										
									}
									else
									{
								?>
								
									<?php
// define variables and set to empty values
$usernameErr = $employee_typeErr = $fnameErr = $lnameErr = "";
$username = $employee_type = $fname = $lname = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username"])) {
    $usernameErr = "UserName is required";
  } else {
    $username = test_input($_POST["username"]);
  }
  
  if (empty($_POST["employee_type"])) {
    $employee_typeErr = "Employee Type is required";
  } else {
    $employee_type = test_input($_POST["employee_type"]);
  }
    
  if (empty($_POST["fname"])) {
    $fname = "";
  } else {
    $fname = test_input($_POST["fname"]);
  }

  if (empty($_POST["lname"])) {
    $lname = "";
  } else {
    $lname = test_input($_POST["lname"]);
  }

  
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								<tr align="left">
									<td>Username</td>
									<td colspan="3"><input type="text" class="textbox" id="username" name="username" onFocus="disable_checkfield"
									onBlur="validate_empid();">
									
									 <span class = "error">* <?php echo $usernameErr;?></span>
									
									
									</td>	
								</tr>
								
								
								
								<tr align="left">
									<td>&nbsp;</td>
									<td colspan="3">
										<br>
										<input class="butclas" type="submit"  value="upload" name="upload">&nbsp;&nbsp;&nbsp;
										<input class="butclas" type="reset" value="Clear">
									</td>
								</tr>
								</form>
								<?php
									} 
									mysqli_close($db);
								?>
							</table>
						</td>
					</tr>		
				</table>
					</td>
					</tr>		
				</table>
			</td>
		</tr>
		<!-- footer start -->
		<tr> 
			<td> 
				<table border="0" width="100%">
					<tr>
						<td>
							<div class="footer"><!--footer start-->
								<p align="center" style="vertical-align:middle; ">
									<font></font> <span><a href="" title="" target="_blank"></a></span>
								</p>
							</div><!--footer end-->
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<!-- footer end -->
		</table>
	</body>
</html>